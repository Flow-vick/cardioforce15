document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const weekNumber = urlParams.get('week');
    const weekTitle = document.getElementById('week-title');
    const exerciseList = document.getElementById('exercise-list');

    weekTitle.textContent = `Semaine ${weekNumber}`;

    // Charger le fichier CSV
    fetch('exercices.csv')
        .then(response => response.text())
        .then(data => {
            const rows = data.split('\n');
            const exercises = [];
            let currentWeek = null;

            // Parse le CSV (séparateur : point-virgule)
            rows.forEach(row => {
                const cols = row.split(';');
                const week = cols[0].trim();

                // Vérifie si la ligne commence une nouvelle semaine
                if (week.startsWith('Semaine')) {
                    currentWeek = week;
                }

                // Ajoute l'exercice uniquement si la semaine correspond
                if (currentWeek === `Semaine ${weekNumber}` && cols[1].trim()) {
                    exercises.push({
                        week: currentWeek,
                        day: cols[1].trim(),
                        sessionName: cols[2].trim(),
                        sessionDetails: cols[3].trim(),
                        repsDuration: cols[4].trim()
                    });
                }
            });

            // Afficher les exercices
            if (exercises.length === 0) {
                exerciseList.innerHTML = '<p>Aucun exercice trouvé pour cette semaine.</p>';
            } else {
                exercises.forEach((exercise, index) => {
                    const exerciseDiv = document.createElement('div');
                    exerciseDiv.classList.add('exercise-item');

                    // Clé unique pour chaque exercice dans localStorage
                    const storageKey = `exercise_${weekNumber}_${exercise.day}_${index}`;
                    const isCompleted = localStorage.getItem(storageKey) === 'true';

                    // Créer le contenu de l'exercice avec une checkbox
                    exerciseDiv.innerHTML = `
                        <div class="exercise-header">
                            <h3>${exercise.day}</h3>
                            <label class="checkbox-container">
                                Terminé
                                <input type="checkbox" class="exercise-checkbox" data-storage-key="${storageKey}" ${isCompleted ? 'checked' : ''}>
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        ${exercise.sessionName ? `<p><strong>Séance :</strong> ${exercise.sessionName}</p>` : ''}
                        <p><strong>Détails :</strong> ${exercise.sessionDetails}</p>
                        ${exercise.repsDuration ? `<p><strong>Rép/Durée :</strong> ${exercise.repsDuration}</p>` : ''}
                    `;
                    exerciseList.appendChild(exerciseDiv);
                });

                // Ajouter un gestionnaire d'événements pour les checkboxes
                const checkboxes = document.querySelectorAll('.exercise-checkbox');
                checkboxes.forEach(checkbox => {
                    checkbox.addEventListener('change', (e) => {
                        const storageKey = e.target.getAttribute('data-storage-key');
                        localStorage.setItem(storageKey, e.target.checked);
                    });
                });
            }
        })
        .catch(error => {
            console.error("Erreur lors du chargement du CSV :", error);
            exerciseList.innerHTML = '<p>Erreur lors du chargement des exercices.</p>';
        });
});